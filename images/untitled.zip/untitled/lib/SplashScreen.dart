import 'package:flutter/cupertino.dart';
import 'package:untitled/sign%20in.dart';

class LodingScreen extends StatefulWidget {
  const LodingScreen({super.key});
  static const routeName='splash';
  @override
  State<LodingScreen> createState() => _LodingScreenState();
}

class _LodingScreenState extends State<LodingScreen> {
  @override
  void initState() {
    super.initState();
    navigateToHome();
  }

  @override
  Widget build(BuildContext context) {
    return  Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF1BCCD9),Color(0xFF0E6C73)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),

      ),
      child: Center(
        child: Image.asset("images/logo_white-removebg-preview 2.png"),

      ),
    );
  }

  void navigateToHome() {
    Future.delayed(
      const Duration(seconds: 1),
          () async {
        Navigator.pushReplacementNamed(context, LoginScreen.routeName);
      },
    );
  }
}