import 'package:flutter/material.dart';
import 'package:untitled/sign%20up.dart';
import 'botton.dart';

class HomeScreeno extends StatelessWidget {
  final List <Map<String, dynamic>> features = [
    {
      "icon": Icons.camera_alt_outlined,
      "title": "Early Detection",
      "description": "Upload a photo of the ultrasound picture to know the risk percentage of your baby having a Down syndrome.",
      "action": "Upload image"
    },
    {
      "icon": Icons.man,
      "title": "Find a Therapist",
      "description": "You can easily find trusted therapists specializing in Down syndrome. We provide a list of recommended professionals with detailed profiles, ratings, and contact information.",
    },
    {
      "icon": Icons.group,
      "title": "Supportive Community",
      "description": "Connect with other parents and families who share similar experiences. Our app provides a safe space to exchange advice, share stories, and offer support.",
    },
    {
      "icon": Icons.video_library_outlined,
      "title": "Helpful Video Library",
      "description": "Explore a collection of videos featuring real-life stories from other parents and individuals with Down syndrome, sharing their experiences and insights, and other educational videos",
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        iconSize: 40,
        backgroundColor: Colors.teal,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {},
            ),
            Text(
              "What is Down Syndrome?",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              "Down syndrome is a genetic condition that occurs when a child is born with an extra copy of chromosome 21...",
              style: TextStyle(fontSize: 16),
            ),
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () {},
                child: Text("Show more"),
              ),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: features.length,
              itemBuilder: (context, index) {
                return _buildFeatureCard(
                  icon: features[index]['icon'],
                  title: features[index]['title'],
                  description: features[index]['description'],
                  actionLabel: features[index].containsKey('action') ? features[index]['action'] : null,
                );
              },
            ),
            SizedBox(height: 5),
            MaterialButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => SignUpScreen()));
              },
              color: Colors.teal,
              textColor: Colors.white,
              child: Text("Go to Sign Up"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeatureCard({
    required IconData icon,
    required String title,
    required String description,
    String? actionLabel,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(4, 4),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.5),
            blurRadius: 8,
            offset: const Offset(-4, -4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(icon, size: 30, color: Colors.black),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                const SizedBox(height: 5),
                Text(
                  description,
                  style: TextStyle(fontSize: 11, color: Colors.black),
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                ),
                if (actionLabel != null)
                  Align(
                    alignment: Alignment.bottomRight,
                    child: InkWell(
                      onTap: () {},
                      child: Text(
                        actionLabel,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: InkWell(
                    onTap: () {},
                    child: const Icon(Icons.arrow_forward_ios, color: Colors.black, size: 18),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
