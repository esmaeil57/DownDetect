import 'package:flutter/material.dart';

class Homepage extends StatelessWidget {
  const Homepage({super.key});

  Widget build(BuildContext context) {
    return Scaffold(
          body:ListView(
        children: [
          Center(
        child: MaterialButton(
        textColor:Colors.white,
      color: Colors.red,
      onPressed: (){
          showDialog(context: context, builder:(context){
            return AlertDialog(
              title:Text("warning"),
              content:Text("do you love her"),
              actions: [
                TextButton(onPressed: (){}, child:Text("yes") ),
                TextButton(onPressed: (){
                  Navigator.of(context).pop();
                }, child:Text("yes") ),
              ],

            );
          });
      },
      child:Text("mawada"),

    ),

      ),
      ],
    ),

    );
  }
}